Appium 

1.Maven project create
2.Appium installation 
3 Inspector installation
3.Test case preparation in feture files
4.Dependency addition
5.io and api difference (io used)
6.Emulator up and running
7.Start session in emulator from inspector json representation
{
"platformName": "Android",
"appium:deviceName": "Pixel 6",
"appium:automationName": "UiAutomator2",
"appium:udid": "Android Emulator",
"appium:avd": "Pixel_6_Pro_API_32",
"appium:fastReset": true,
"appium:newCommandTimeout": 5
}
8.Create step definitions
9.Implement appium driver launch code scripts
10. we faced session url issue so it should be /wd/hub