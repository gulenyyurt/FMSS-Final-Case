package pages;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.remote.options.BaseOptions;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.TimeUnit;

public class LoginPage extends BasePage {

    public WebElement getUserNameElm(){
        WebElement userNameElm = driver.findElement(By.id("username_loc"));
        return userNameElm;
    }

    public WebElement getPasswordElm(){
        WebElement passwordElm = driver.findElement(By.id("password_loc"));
        return passwordElm;
    }

    public WebElement getLoginBtn(){
        WebElement loginBtn = driver.findElement(By.id("login_loc"));
        return loginBtn;
    }

    public void fillUserNameAndPass(String user,String pass) {
        getPasswordElm().sendKeys(user);
        getPasswordElm().sendKeys(pass);
    }

    public void clickLogin() {
        getLoginBtn().click();
    }

}
