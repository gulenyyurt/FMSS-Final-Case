package pages;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.remote.options.BaseOptions;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import java.net.MalformedURLException;
import java.net.URL;

public class LogoutPage {
    AppiumDriver driver;

    public LogoutPage() {
        var options=new BaseOptions()
                .amend("platformName", "Android")
                .amend("appium:deviceName", "Pixel 6")
                .amend("appium:automationName", "UiAutomator2")
                .amend("appium:udid", "Android Emulator")
                .amend("appium:avd", "Pixel_6_Pro_API_32")
                .amend("appium:fastReset", true)
                .amend("appium:newCommandTimeout", 5)
                .amend("appium:ensureWebviewsHavePages", true)
                .amend("appium:nativeWebScreenshot", true)
                .amend("appium:connectHardwareKeyboard", true)
                .amend("appium:app", "/Users/sahinyesilyurt/Desktop/appiumapk/carigo.apk");
        driver = new AppiumDriver(this.getUrl(), options);
    }

    private URL getUrl(){
        try {
            return new URL("http://127.0.0.1:4723/wd/hub");
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public void goMyAccount(){
        WebElement myAccountBtn = driver.findElement(By.id("my_acc_btn_loc"));
        myAccountBtn.click();
    }

    public void logout(){
        WebElement logoutBtn = driver.findElement(By.id(("log_out")));
        logoutBtn.click();
    }
}
