package pages;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.remote.options.BaseOptions;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.HashSet;
import java.util.Set;

public class SignupPage extends BasePage {

    Set<String> emailSet=new HashSet<>();

    public void fillFirstName(String firstName){
        WebElement firstNameField=driver.findElement(By.id("firstName_id_loc"));
        firstNameField.sendKeys(firstName);
    }

    public void fillLastName(String lastName){
        WebElement lastNameField=driver.findElement(By.id("lastName_id_loc"));
        lastNameField.sendKeys(lastName);
    }

    public void fillEmail(String email){
        WebElement emailField=driver.findElement(By.id("email_id_loc"));
        emailField.sendKeys(email);
    }
    public void fillPhoneNumber(String phoneNumber){
        WebElement phoneNumberField=driver.findElement(By.id("phoneNumber_id_loc"));
        phoneNumberField.sendKeys(phoneNumber);
    }
    public void fillPassword(String password){
        WebElement passwordField=driver.findElement(By.id("password_id_loc"));
        passwordField.sendKeys(password);
    }
    public void fillConfirmPassword(String cpassword){
        WebElement confirmPasswordField=driver.findElement(By.id("confirmPassword_id_loc"));
        confirmPasswordField.sendKeys(cpassword);
    }
    public void filluserAgreement1(){
        WebElement userAgreement1Field=driver.findElement(By.id("userAgreement_id_loc"));
        userAgreement1Field.click();
    }
    public void filluserAgreement2(){
        WebElement userAgreement2Field=driver.findElement(By.id("userAgreement2_id_loc"));
        userAgreement2Field.click();
    }
    public void signUp(){
        WebElement signupButton=driver.findElement(By.id("signupButton_id_loc"));
        signupButton.click();
    }
}
