package steps;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pages.SignupPage;

import static org.junit.Assert.assertTrue;

public class SignupStep {

    SignupPage signupPage;

    public SignupStep(){
        signupPage = new SignupPage();
    }

    @Given("user Opens App")
    public void userOpensApp(){
        signupPage.openApp();
    }

    @When("User makes registration by filling fields")
    public void fillField(){
        signupPage.fillFirstName("Gülen");
        signupPage.fillLastName("Yeşilyurt");
        signupPage.fillEmail("gulenyyurt@gmail.com");
        signupPage.fillPhoneNumber("54162220000");
        signupPage.fillPassword("123456");
        signupPage.fillConfirmPassword("123456");
        signupPage.filluserAgreement1();
        signupPage.filluserAgreement2();
        signupPage.signUp();

    }

    @Then("User registers successfully")
    public void userRegistersSuccessfully() {
        assertTrue("Registered",true);
    }

    @When("User fills in the field with the same email")
    public void fillSameEmail(){
        signupPage.fillEmail("same@gmail.com");
        signupPage.signUp();
    }

    @Then("user displays the error message")
    public void userRegisterSameEmail() {
        assertTrue("Not Registered",true);
    }

    @When("User fills in the field with the same phone number")
    public void fillSamePhoneNumber(){
        signupPage.fillPhoneNumber("54162220000");
        signupPage.signUp();

    }

    @When("User fills in the  password fields with the different password")
    public void fillDiffPassword(){
        signupPage.fillPassword("123456");
        signupPage.fillConfirmPassword("654321");
        signupPage.signUp();
    }
}
