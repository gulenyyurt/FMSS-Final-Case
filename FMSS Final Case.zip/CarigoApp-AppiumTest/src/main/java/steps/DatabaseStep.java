package steps;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class DatabaseStep {
    @Given("User has customer_address table fk")
    public void userHasAddressTableFk() {
    }

    @When("User add one customer_address")
    public void userAddOneAddress() {
    }

    @Then("customer_address table has customer_id is filled")
    public void addressTableHasUser_idIsFilled() {
    }

    @Given("User has vehicle_address table fk")
    public void userHasVehicleAddress() {
    }

    @When("User add one vehicle_address")
    public void userAddOneVehicleAddress() {
    }

    @Then("vehicle_address table has vehicle_id is filled")
    public void vehicleAddressTableHasUser_idIsFilled() {
    }

    @Given("User has rentals table fk")
    public void userHasRental() {
    }

    @When("User add one rental_id")
    public void userAddOneRentalId() {
    }

    @Then("rentals table has customer_id is filled")
    public void rentalTableHasUser_idIsFilled() {
    }

    @Then("rentals table has vehicle_id is filled")
    public void rentalTableHasVehicle_idIsFilled() {
    }

    @Given("User has Vehicle Maintenance table fk")
    public void userHasVehicleMaintance() {
    }

    @When("User add one vehicle maintenance")
    public void userAddOneVehicleMaintenance() {
    }

    @Then("Vehicle Maintenance  table has vehicle_id is filled")
    public void vehicleMainHasVehicle_idIsFilled() {
    }

    @Given("User has customer table pk")
    public void userHasCustomerPk() {
    }

    @When("User add one customer with the same customer_id")
    public void userAddedSameCustomer() {
    }

    @Then("User is shown error message 'customer table must be populated with unique customer_id'")
    public void userGetError() {
    }

    @Given("User has customer_adress table pk")
    public void userHasCustomerAddressPk() {
    }

    @When("User add one customer_adress with the same adress_id")
    public void userAddedSameAddressId() {
    }

    @Then("User is shown error message 'customer_adress table must be populated with unique adress_id'")
    public void userGetErrorAddressId() {
    }

    @Given("User has vehicles table pk")
    public void userHasVehiclePk() {
    }

    @When("User add one customer with the same vehicle_id")
    public void userAddedSameVehicleId() {
    }

    @Then("User is shown error message 'vehicles table must be populated with unique vehicle_id'")
    public void userGetErrorVehicleId() {
    }


}
