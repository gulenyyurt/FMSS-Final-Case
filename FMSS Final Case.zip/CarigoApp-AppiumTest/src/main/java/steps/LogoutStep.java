package steps;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pages.LoginPage;
import pages.LogoutPage;

import static org.junit.Assert.assertTrue;

public class LogoutStep {
    LoginPage loginPage;
    LogoutPage logoutPage;

    public LogoutStep(){
        loginPage = new LoginPage();
        logoutPage =  new LogoutPage();
    }

    @Given("Given The user have to logged in")
    public void userHavetoLogin() {
        loginPage.fillUserNameAndPass("admin","123456");
    }

    @When("The clicked my account menu")
    public void myAccount(){
        logoutPage.goMyAccount();
    }

    @And("The user clicked log out")
    public void clickLogout(){
        logoutPage.logout();
    }

    @Then("The user should be navigate to login page")
    public void navigateLogin(){
        assertTrue("Login Page Navigated",true);
    }
}
