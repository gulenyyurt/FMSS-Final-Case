package steps;


import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.remote.options.BaseOptions;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.openqa.selenium.By;
import org.openqa.selenium.remote.DesiredCapabilities;
import pages.LoginPage;
import pages.SignupPage;

import java.net.MalformedURLException;
import java.net.URL;
import java.time.Duration;
import java.util.concurrent.TimeUnit;

import static org.junit.Assert.assertTrue;

public class LoginStep {
    LoginPage loginPage;
    public LoginStep(){
        loginPage = new LoginPage();
    }

    @Given("user opens Carigo app")
    public void userOpensApp() {
       loginPage.openApp();
    }

    @When("The user enters valid username and password")
    public void userFillsUsername() {
        loginPage.fillUserNameAndPass("admin","123456");
    }

    @And("The user clicks on the login button")
    public void userClickLogin() {
        loginPage.clickLogin();
    }

    @Then("The user should be redirected to the app")
    public void userRedirectApp(String username) {
        assertTrue("User loggen in", true);
    }

    @When("The user enters invalid username and password")
    public void invalidUsernamePass(){
        loginPage.fillUserNameAndPass("invalid","987654");
    }

    @Then("The user get an error message in display")
    public void userSawError(String username) {
        assertTrue("User saw error", true);
    }

    @When("The user enters invalid username and valid password")
    public void invalidUsernameValidPass(){
        loginPage.fillUserNameAndPass("invalid","123456");
    }

    @When("The user enters valid username and invalid password")
    public void validUsernameInvalidPass(){
        loginPage.fillUserNameAndPass("admin","987654");
    }

}
